
The NightCrawler; Devia v2.

Made for Depthcore's pack #9 Technica.

"Sadly, this is the last skin we will be making as a member of DC. There's no significant reason why we are leaving, we just feel it is time to move on.

We have thoroughly enjoyed our time in DC and wish the group all the best in their future endevours.

Let this skin be a tribute and a testament to the greatness that is Depthcore."

     - Anuja and Arjuna Navaratna (t-k)


(c) 2003 Anuja Navaratna and t-k

t-k.deviantart.com - for more skins.
aabros@sltnet.lk - for hate mail.